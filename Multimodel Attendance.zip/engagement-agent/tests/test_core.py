import numpy as np, pandas as pd
from engagement import attendance, pipeline

def synth():
    rows = []
    for t in np.arange(0, 600, 1/3):
        drop = 240 <= t < 360
        for tid in (1, 2):
            rows.append(dict(t=t, track_id=tid, yaw=60 if drop else 5, pitch=0, move=0.0 if drop else 0.015))
    rows.append(dict(t=10, track_id=3, yaw=0, pitch=0, move=0.01))   # transient
    return pd.DataFrame(rows)

def test_attendance():
    a = attendance.compute(synth(), 600).set_index("track_id")
    assert a.loc[1, "status"] == "Present" and a.loc[3, "status"] != "Present"

def test_drop_detected(tmp_path):
    r = pipeline.analyse(synth(), np.full(20, 0.1), 600, str(tmp_path))
    drops = [f for f in r["findings"] if f["type"] == "attention_drop"]
    assert drops and 200 <= drops[0]["start_s"] <= 270
    assert r["suggestions"]
