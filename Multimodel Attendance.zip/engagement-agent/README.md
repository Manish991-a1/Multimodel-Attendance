# Multimodal Attendance & Engagement Agent
Offline classroom analytics: attendance (sustained presence), engagement (head pose + movement + inactivity + room audio), advisory teaching suggestions.

## Deploy
**Docker (recommended)**
```
docker compose up -d --build
docker compose exec ollama ollama pull phi3   # optional, enables LLM suggestions
```
Open http://localhost:8501 and upload a recording.

**Local**
```
pip install -r requirements.txt   # needs ffmpeg on PATH
pytest -q
streamlit run dashboard.py
python cli.py session.mp4 --out data
```
## Config (env vars)
SAMPLE_FPS (3), WINDOW_S (30), OLLAMA_URL, OLLAMA_MODEL. Thresholds in engagement/config.py.

## Privacy
No cloud calls. Video is not stored (dashboard deletes uploads); only per-window metrics and anonymous track IDs are written to `data/`. Delete `data/` to purge. Scores are proxies, not proof of attention; review class-level trends first. Obtain consent before deployment.

## Not included yet
Face-ID roster matching, live camera input, bias evaluation.
