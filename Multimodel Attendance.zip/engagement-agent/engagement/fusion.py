import numpy as np, pandas as pd
from . import config as C

def windows(obs, speech, duration):
    if obs.empty: return pd.DataFrame()
    o = obs.copy(); o["w"] = (o.t // C.WINDOW_S).astype(int)
    o["front"] = ((o.yaw.abs() < C.YAW_MAX) & (o.pitch.abs() < C.PITCH_MAX)).astype(float)
    o["idle"] = (o.move < C.IDLE_EPS).astype(float)
    o["mv"] = (o.move / C.MOVE_REF).clip(0, 1)
    pw = o.groupby(["w","track_id"]).agg(attention=("front","mean"), movement=("mv","mean"), idle=("idle","mean")).reset_index()
    pw["audio"] = pw.w.map(lambda i: speech[i] if i < len(speech) else 0.0)
    pw["score"] = (C.W["attention"]*pw.attention + C.W["movement"]*pw.movement
                   + C.W["active"]*(1-pw.idle) + C.W["audio"]*pw.audio).clip(0, 1)
    pw["t_start"] = pw.w * C.WINDOW_S
    return pw

def class_trend(pw):
    if pw.empty: return pw
    c = pw.groupby(["w","t_start"]).agg(score=("score","mean"), attention=("attention","mean"),
                                        audio=("audio","first"), n=("track_id","nunique")).reset_index()
    c["smooth"] = c.score.rolling(3, center=True, min_periods=1).median()
    return c

def findings(c):
    if len(c) < 4: return []
    mu, sd = c.smooth.mean(), c.smooth.std() or 1e-9
    z = ((c.smooth - mu) / sd).reset_index(drop=True); c = c.reset_index(drop=True); out = []
    def runs(mask, kind):
        start = None
        for i, m in enumerate(list(mask) + [False]):
            if m and start is None: start = i
            if not m and start is not None:
                seg = c.iloc[start:i]
                out.append(dict(type=kind, start_s=int(seg.t_start.iloc[0]), duration_min=round(len(seg)*C.WINDOW_S/60, 1),
                                class_avg=round(float(seg.smooth.mean()), 2), session_avg=round(float(mu), 2)))
                start = None
    runs(z < -1.0, "attention_drop")
    runs((c.audio > 0.3) & (z > 0.5), "interaction_peak")
    if sd < 0.03: out.append(dict(type="flat_engagement", session_avg=round(float(mu),2)))
    return out
