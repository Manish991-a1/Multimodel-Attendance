"""Advisory suggestions. Rules first; optional local LLM (Ollama) sees only anonymous JSON findings."""
import json, urllib.request
from . import config as C

def _mmss(s): return f"{s//60:02d}:{s%60:02d}"

def rule_suggestions(findings):
    out = []
    for f in findings:
        if f["type"] == "attention_drop":
            out.append(f"Attention dipped around {_mmss(f['start_s'])} for ~{f['duration_min']} min (class avg {f['class_avg']} vs {f['session_avg']}). Consider a quick poll, pair discussion, or short break near that point.")
        elif f["type"] == "interaction_peak":
            out.append(f"Interaction peaked at {_mmss(f['start_s'])}. The activity or format used then worked well; consider repeating it.")
        elif f["type"] == "flat_engagement":
            out.append("Engagement was uniformly flat. Varying format (demo, Q&A, group task) may help.")
    return out or ["No notable engagement events detected."]

def llm_suggestions(findings, timeout=60):
    prompt = ("You are a teaching assistant. Given anonymous classroom engagement findings (JSON), give 3 short, practical, advisory suggestions. "
              "Do not make claims about individuals.\n" + json.dumps(findings))
    req = urllib.request.Request(C.OLLAMA_URL, json.dumps({"model": C.OLLAMA_MODEL, "prompt": prompt, "stream": False}).encode(),
                                 {"Content-Type": "application/json"})
    try:
        return json.loads(urllib.request.urlopen(req, timeout=timeout).read())["response"].strip()
    except Exception:
        return None
