import json, os, pandas as pd
from . import vision, audio, attendance, fusion, agent

def run(video, out_dir="data", use_llm=False, progress=None):
    rows, dur = vision.process_video(video, progress=progress)
    obs = pd.DataFrame(rows, columns=["t","track_id","yaw","pitch","move"])
    return analyse(obs, audio.speech_ratio_by_window(video, dur), dur, out_dir, use_llm)

def analyse(obs, speech, dur, out_dir="data", use_llm=False):
    os.makedirs(out_dir, exist_ok=True)
    att = attendance.compute(obs, dur)
    pw = fusion.windows(obs, speech, dur); trend = fusion.class_trend(pw); f = fusion.findings(trend)
    res = dict(duration_s=dur, attendance=att, windows=pw, trend=trend, findings=f,
               suggestions=agent.rule_suggestions(f), llm=agent.llm_suggestions(f) if use_llm else None)
    att.to_csv(f"{out_dir}/attendance.csv", index=False); pw.to_csv(f"{out_dir}/engagement_windows.csv", index=False)
    json.dump(dict(findings=f, suggestions=res["suggestions"], llm=res["llm"]), open(f"{out_dir}/report.json", "w"), indent=2)
    return res
