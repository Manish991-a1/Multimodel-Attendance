import pandas as pd
from . import config as C

def compute(obs: pd.DataFrame, duration: float) -> pd.DataFrame:
    cols = ["track_id","first_seen","last_seen","present_s","longest_streak_s","ratio","status"]
    if obs.empty: return pd.DataFrame(columns=cols)
    rows = []
    for tid, g in obs.groupby("track_id"):
        ts = sorted(g.t); segs, s, p = [], ts[0], ts[0]
        for t in ts[1:]:
            if t - p > C.GAP_TOL_S: segs.append((s, p)); s = t
            p = t
        segs.append((s, p))
        present = sum(b-a for a, b in segs); streak = max(b-a for a, b in segs)
        ratio = present / duration if duration else 0
        ok = ratio >= C.PRESENT_RATIO or streak >= C.PRESENT_STREAK_S
        rows.append(dict(track_id=tid, first_seen=ts[0], last_seen=ts[-1], present_s=round(present,1),
                         longest_streak_s=round(streak,1), ratio=round(ratio,3), status="Present" if ok else "Absent/Transient"))
    return pd.DataFrame(rows, columns=cols)
