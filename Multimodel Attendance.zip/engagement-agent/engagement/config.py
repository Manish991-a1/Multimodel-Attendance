import os
SAMPLE_FPS = float(os.getenv("SAMPLE_FPS", 3))
WINDOW_S = int(os.getenv("WINDOW_S", 30))
GAP_TOL_S = 30            # gap tolerated before presence breaks
PRESENT_RATIO = 0.60      # >=60% of session
PRESENT_STREAK_S = 300    # or 5 continuous minutes
YAW_MAX, PITCH_MAX = 25, 25
MOVE_REF = 0.02           # normalised displacement counted as "fully active"
IDLE_EPS = 0.001
W = dict(attention=0.45, movement=0.20, active=0.20, audio=0.15)
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434/api/generate")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "phi3")
