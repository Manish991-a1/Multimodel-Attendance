"""Room-level audio activity via ffmpeg + RMS energy (offline, no speech content kept)."""
import subprocess, tempfile, wave, os, numpy as np
from . import config as C

def speech_ratio_by_window(video_path, duration):
    n = int(np.ceil(duration / C.WINDOW_S)) or 1
    try:
        with tempfile.TemporaryDirectory() as d:
            wav = os.path.join(d, "a.wav")
            subprocess.run(["ffmpeg","-y","-i",video_path,"-ac","1","-ar","16000","-vn",wav], check=True, capture_output=True)
            with wave.open(wav) as w:
                sr = w.getframerate(); x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32)/32768
    except Exception:
        return np.zeros(n)   # no audio track / ffmpeg missing
    hop = int(sr*0.5); k = len(x)//hop
    rms = np.sqrt((x[:k*hop].reshape(k, hop)**2).mean(1)) if k else np.zeros(1)
    flag = rms > max(np.median(rms)*2.5, 0.01)
    per = int(C.WINDOW_S/0.5)
    return np.array([flag[i*per:(i+1)*per].mean() if len(flag[i*per:(i+1)*per]) else 0.0 for i in range(n)])
