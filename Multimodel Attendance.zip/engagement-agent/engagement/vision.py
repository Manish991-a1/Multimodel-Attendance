"""Face mesh -> per-track observations (t, track_id, yaw, pitch, move). No frames are stored."""
import cv2, numpy as np
from . import config as C

IDX = [1, 152, 33, 263, 61, 291]
MODEL = np.array([(0,0,0),(0,-63.6,-12.5),(-43.3,32.7,-26),(43.3,32.7,-26),(-28.9,-28.9,-24.1),(28.9,-28.9,-24.1)], dtype=np.float64)

class Tracker:
    def __init__(self, max_dist=0.08, ttl=2.0):
        self.tracks, self.next, self.max_dist, self.ttl = {}, 1, max_dist, ttl
    def update(self, t, centroids):
        out, used = [], set()
        for c in centroids:
            best, bd = None, self.max_dist
            for tid, (pc, pt) in self.tracks.items():
                d = float(np.hypot(*(np.array(c) - pc)))
                if tid not in used and d < bd and t - pt <= self.ttl:
                    best, bd = tid, d
            if best is None:
                best, bd = self.next, 0.0; self.next += 1
            used.add(best); self.tracks[best] = (np.array(c), t); out.append((best, bd))
        return out

def pose(lm, w, h):
    pts = np.array([(lm[i].x*w, lm[i].y*h) for i in IDX], dtype=np.float64)
    cam = np.array([[w,0,w/2],[0,w,h/2],[0,0,1]], dtype=np.float64)
    ok, rv, _ = cv2.solvePnP(MODEL, pts, cam, np.zeros((4,1)), flags=cv2.SOLVEPNP_ITERATIVE)
    if not ok: return None
    ang = cv2.RQDecomp3x3(cv2.Rodrigues(rv)[0])[0]
    pitch, yaw = ang[0], ang[1]
    pitch = ((pitch + 180) % 360) - 180
    if abs(pitch) > 90: pitch = 180 - abs(pitch) if pitch > 0 else -(180 - abs(pitch))
    return float(yaw), float(pitch)

def process_video(path, max_faces=40, progress=None):
    import mediapipe as mp
    cap = cv2.VideoCapture(path)
    if not cap.isOpened(): raise IOError(f"Cannot open {path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    step = max(1, int(round(fps / C.SAMPLE_FPS)))
    mesh = mp.solutions.face_mesh.FaceMesh(static_image_mode=False, max_num_faces=max_faces, refine_landmarks=False, min_detection_confidence=0.5)
    tr, rows, i = Tracker(), [], 0
    while True:
        ok, frame = cap.read()
        if not ok: break
        if i % step == 0:
            t = i / fps; h, w = frame.shape[:2]
            res = mesh.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            faces = res.multi_face_landmarks or []
            cents = [(f.landmark[1].x, f.landmark[1].y) for f in faces]
            for (tid, move), f in zip(tr.update(t, cents), faces):
                p = pose(f.landmark, w, h)
                if p: rows.append(dict(t=t, track_id=tid, yaw=p[0], pitch=p[1], move=move))
            if progress and total: progress(min(i/total, 1.0))
        i += 1
    cap.release(); mesh.close()
    return rows, i / fps
