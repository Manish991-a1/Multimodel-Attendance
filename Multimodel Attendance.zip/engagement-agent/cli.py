import argparse, json
from engagement.pipeline import run
p = argparse.ArgumentParser(description="Multimodal Attendance & Engagement Agent")
p.add_argument("video"); p.add_argument("--out", default="data"); p.add_argument("--llm", action="store_true")
a = p.parse_args(); r = run(a.video, a.out, a.llm)
print(r["attendance"].to_string(index=False)); print(json.dumps(r["findings"], indent=2))
for s in r["suggestions"]: print("-", s)
