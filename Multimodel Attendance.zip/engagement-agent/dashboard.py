import os, tempfile, streamlit as st
from engagement.pipeline import run
st.set_page_config(page_title="Engagement Agent", layout="wide")
st.title("Multimodal Attendance & Engagement Agent")
st.caption("Runs fully offline. Only derived metrics are stored; video is deleted after analysis. Scores are advisory.")
up = st.file_uploader("Session recording", type=["mp4","avi","mov","mkv"])
llm = st.checkbox("Use local LLM (Ollama) for extra suggestions")
if up and st.button("Analyse"):
    with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(up.name)[1]) as f:
        f.write(up.read()); path = f.name
    bar = st.progress(0.0)
    try: r = run(path, "data", llm, progress=bar.progress)
    finally: os.remove(path)
    st.session_state["r"] = r
r = st.session_state.get("r")
if r:
    a, b = st.columns(2)
    a.subheader("Attendance"); a.dataframe(r["attendance"], use_container_width=True)
    b.subheader("Class engagement over time")
    if not r["trend"].empty: b.line_chart(r["trend"].set_index("t_start")[["score","smooth"]])
    st.subheader("Suggestions (advisory)")
    for s in r["suggestions"]: st.write("•", s)
    if r["llm"]: st.info(r["llm"])
    with st.expander("Evidence"): st.json(r["findings"])
